﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SMS.PL
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try 
            {
                LoginUser user = new LoginUser();

                user.UserName = txtUserName.Text;
                user.Password = txtPassword.Text;

                string userName = LoginUserValidations.ValidateLogin(user);

                if (userName != "")
                {
                    Session["user"] = userName;
                    Response.Redirect("Welcome.aspx");
                }
                else
                    throw new LoginUserException("UserName/Password is incorrect");
            }
            catch (LoginUserException ex)
            {
                lblError.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                lblError.Text = ex.Message;
            }
        }
    }
}