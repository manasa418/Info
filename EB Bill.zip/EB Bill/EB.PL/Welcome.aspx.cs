﻿using EB.BL;
using EB.Entity;
using EB.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EB.PL
{
    public partial class Welcome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            Master.Logout = true;
            Master.Menu = true;
            lblWelcome.Text = "Welcome " + Session["user"];

            try
            {
                List<Electricity> empList = ElectricityValidation.DisplayEB();
                gvEB.DataSource = empList;
                gvEB.DataBind();
            }
            catch (ElectricityException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }
    }
}