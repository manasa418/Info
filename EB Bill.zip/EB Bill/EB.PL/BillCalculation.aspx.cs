﻿using EB.BL;
using EB.Entity;
using EB.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EB.PL
{
    public partial class BillCalculation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            Master.Logout = true;
            Master.Menu = true;
        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                Electricity ele = new Electricity();
                ele.ConsumerId = Convert.ToInt32(txtConsumerId.Text);
                ele.ConsumerName = txtConsumerName.Text;
                ele.LMR = Convert.ToInt32(txtLMR.Text);
                ele.CMR = Convert.ToInt32(txtCMR.Text);

                int cal = 0;

                cal = ele.CMR - ele.LMR;             
               
                ElectricityValidation val = new ElectricityValidation();
                int cost = val.TotalCost(cal);

                txtUnitsConsumed.Text = cal.ToString();
                txtTotalAmount.Text = cost.ToString();

                ele.UnitsConsumed= Convert.ToInt32(txtUnitsConsumed.Text);
                ele.TotalAmount = Convert.ToInt32(txtTotalAmount.Text);
              
                int recordsAffected = ElectricityValidation.InsertDetails(ele);

                if(recordsAffected>0)
                {
                    Response.Write("<script type='text/javascript'>alert('Details are Inserted Successfully');</script>");
                }
                else
                {
                    throw new ElectricityException("Details are not inserted");
                }
            }
            catch (ElectricityException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }

      }
    }
