create table Manasa.EBill_LoginUser_150906
(
UserName varchar(20),                             
Password varchar(20)
);

insert into Manasa.EBill_LoginUser_150906(UserName,Password)
values('manasa','manasa@123')

values('admin','admin@123')

('pravin','pravin@123')

drop  table Manasa.EBill_LoginUser_150906

select * from Manasa.EBill_LoginUser_150906

CREATE PROC Manasa.[usp_ValidateLoginEBills_150906]
(
@username VARCHAR(20),
@password VARCHAR(20)
)
AS                                            
BEGIN
SELECT UserName
FROM Manasa.EBill_LoginUser_150906
WHERE UserName = @username AND Password = @password
END

select * from Manasa.EBill_LoginUser_150906

create table Manasa.EBill_ASP_150906
(
ConsumerId int Primary key,
ConsumerName varchar(20),
LMR int,
CMR int,
UnitsConsumed int,
TotalAmount int
);
select * from Manasa.EBill_ASP_150906

drop table Manasa.EBill_ASP_150906
Create proc Manasa.usp_InsertEBill_150906
(
@cId INT,
@cname VARCHAR(50),
@lmr INT,
@cmr INT,
@uc int,
@ta int
)
AS
BEGIN
INSERT INTO EBill_ASP_150906 (ConsumerId, ConsumerName, LMR, CMR,UnitsConsumed,TotalAmount)
VALUES (@cId, @cname, @lmr, @cmr,@uc,@ta)
END

CREATE PROC Manasa.usp_SearchEBill_150906
(
@cId  INT
)
AS
BEGIN
SELECT * FROM EBill_ASP_150906 WHERE ConsumerId = @cId
END

CREATE PROC Manasa.DisplayEBill_150906
AS
BEGIN
SELECT * FROM Manasa.EBill_ASP_150906
END

select * from Manasa.EBill_ASP_150906