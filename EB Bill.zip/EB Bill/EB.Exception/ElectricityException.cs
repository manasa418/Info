﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EB.Exception
{
    public class ElectricityException : ApplicationException
    {
        public ElectricityException()
            : base()
        { }

        public ElectricityException(string message)
            : base(message)
        { }
    }
}
