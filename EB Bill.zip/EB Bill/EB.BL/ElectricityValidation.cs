﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EB.Entity;
using EB.DAL;
using EB.Exception;

namespace EB.BL
{
    public class ElectricityValidation
    {
        public static int InsertDetails(Electricity ele)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = ElectricityOperations.InsertDetails(ele);
            }
            catch (ElectricityException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static List<Electricity> DisplayEB()
        {
            List<Electricity> eleList = null;

            try
            {
                eleList = ElectricityOperations.DisplayEB();
            }
            catch (ElectricityException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return eleList;
        }

        public int TotalCost(int cal)
        {
            ElectricityOperations op = new ElectricityOperations();
            int total=0;
           if(cal>=1 && cal<=100)
            {
               int des = 2;
                total = op.Total(cal,des);
            }
           else if(cal>100 && cal<=250)
            {
                int des = 3;
                total = op.Total(cal, des);
            }
           else if(cal>250)
            {
                int des = 6;
                total = op.Total(cal, des);
            }
            return total;
        }

        public static Electricity SearchDetails(int id)
        {
            Electricity ele = null;

            try
            {
                ele = ElectricityOperations.SearchDetails(id);
            }
            catch (ElectricityException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ele;
        }
    }
}
