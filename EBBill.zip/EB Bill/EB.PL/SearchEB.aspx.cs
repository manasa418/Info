﻿using EB.BL;
using EB.Entity;
using EB.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EB.PL
{
    public partial class SearchEB : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            Master.Logout = true;
            Master.Menu = true;
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Electricity ele = new Electricity();

                int id = Convert.ToInt32(txtConsumerId.Text);
                ele = ElectricityValidation.SearchDetails(id);

                txtConsumerName.Text = ele.ConsumerName;
                txtLMR.Text = ele.LMR.ToString();
                txtCMR.Text = ele.CMR.ToString();
                txtUnitsConsumed.Text = ele.UnitsConsumed.ToString();
                txtTotalAmount.Text = ele.TotalAmount.ToString();
            }
            catch (ElectricityException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }

            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }
    }
}