create table Keerthikadevi.EB_LoginUser_150772
(
UserName varchar(20),                             
Password varchar(20)
);

insert into Keerthikadevi.EB_LoginUser_150772(UserName,Password)
values('admin','admin@123'),
('pravin','pravin@123')


CREATE PROC Keerthikadevi.[usp_ValidateLoginEB_150772]
(
@username VARCHAR(20),
@password VARCHAR(20)
)
AS                                            
BEGIN
SELECT UserName
FROM EB_LoginUser_150772
WHERE UserName = @username AND Password = @password
END

select * from Keerthikadevi.EB_LoginUser_150772

create table Keerthikadevi.EB_ASP_150772
(
ConsumerId int,
ConsumerName varchar(20),
LMR int,
CMR int,
UnitsConsumed int,
TotalAmount int
);

Create proc Keerthikadevi.usp_InsertEB_150772
(
@cId INT,
@cname VARCHAR(50),
@lmr INT,
@cmr INT,
@uc int,
@ta int
)
AS
BEGIN
INSERT INTO EB_ASP_150772 (ConsumerId, ConsumerName, LMR, CMR,UnitsConsumed,TotalAmount)
VALUES (@cId, @cname, @lmr, @cmr,@uc,@ta)
END

CREATE PROC Keerthikadevi.usp_SearchEB_150772
(
@cId  INT
)
AS
BEGIN
SELECT * FROM EB_ASP_150772 WHERE ConsumerId = @cId
END

CREATE PROC Keerthikadevi.DisplayEB_150772
AS
BEGIN
SELECT * FROM Keerthikadevi.EB_ASP_150772
END

select * from Keerthikadevi.EB_ASP_150772