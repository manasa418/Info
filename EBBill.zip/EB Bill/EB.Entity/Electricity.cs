﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EB.Entity
{
    public class Electricity
    {
        public int ConsumerId { get; set; }
        public string ConsumerName { get; set; }
        public int LMR { get; set; }
        public int CMR { get; set; }
        public int UnitsConsumed { get; set; }
        public int TotalAmount { get; set; }
    }
}
