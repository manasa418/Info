﻿using EB.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EB.DAL
{
    public class LoginUserOperations
    {
        public static string ValidateLogin(LoginUser user)
        {
            string userName = "";

            try
            {
                SqlCommand cmd = DataConnections.GenerateCommand();
                cmd.CommandText = "Keerthikadevi.[usp_ValidateLoginEB_150772]";

                cmd.Parameters.AddWithValue("@username", user.UserName);
                cmd.Parameters.AddWithValue("@password", user.Password);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    dr.Read();
                    userName = dr["UserName"].ToString();
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }
    }
}
