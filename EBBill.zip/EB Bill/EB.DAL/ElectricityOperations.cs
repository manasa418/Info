﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EB.Entity;
using System.Data.SqlClient;

namespace EB.DAL
{
    public class ElectricityOperations
    {
        public static int InsertDetails(Electricity ele)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnections.GenerateCommand();
                cmd.CommandText = "[Keerthikadevi].[usp_InsertEB_150772]";

                cmd.Parameters.AddWithValue("@cId", ele.ConsumerId);
                cmd.Parameters.AddWithValue("@cname", ele.ConsumerName);
                cmd.Parameters.AddWithValue("@lmr",ele.LMR);
                cmd.Parameters.AddWithValue("@cmr", ele.CMR);
                cmd.Parameters.AddWithValue("@uc", ele.UnitsConsumed);
                cmd.Parameters.AddWithValue("@ta", ele.TotalAmount);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }

            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static List<Electricity> DisplayEB()
        {
            List<Electricity> eleList = null;

            try
            {
                SqlCommand cmd = DataConnections.GenerateCommand();
                cmd.CommandText = "[Keerthikadevi].[DisplayEB_150772]";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    eleList = new List<Electricity>();
                    while (dr.Read())
                    {
                        Electricity ele = new Electricity();
                        ele.ConsumerId = Convert.ToInt32(dr["ConsumerId"]);
                        ele.ConsumerName = dr["ConsumerName"].ToString();
                        ele.LMR = Convert.ToInt32(dr["LMR"]);
                        ele.CMR = Convert.ToInt32(dr["CMR"]);
                        ele.UnitsConsumed = Convert.ToInt32(dr["UnitsConsumed"]);
                        ele.TotalAmount = Convert.ToInt32(dr["TotalAmount"]);

                        eleList.Add(ele);
                    }
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return eleList;
        }

        public int Total(int cal, int des)
        {
            int a = cal * des;
            return a;
        }

        public static Electricity SearchDetails(int ConsumerId)
        {
            Electricity ele = null;
            try
            {
                SqlCommand cmd = DataConnections.GenerateCommand();
                cmd.CommandText = "[Keerthikadevi].[usp_SearchEB_150772]";

                cmd.Parameters.AddWithValue("@cId", ConsumerId);
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    ele = new Electricity();
                    ele.ConsumerId = Convert.ToInt32(dr["ConsumerId"]);
                    ele.ConsumerName = dr["ConsumerName"].ToString();
                    ele.LMR = Convert.ToInt32(dr["LMR"]);
                    ele.CMR = Convert.ToInt32(dr["CMR"]);
                    ele.UnitsConsumed= Convert.ToInt32(dr["UnitsConsumed"]);
                    ele.TotalAmount = Convert.ToInt32(dr["TotalAmount"]);
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ele;
        }
    }
}
