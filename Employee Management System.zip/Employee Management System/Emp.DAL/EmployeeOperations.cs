﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Emp.Entity;
using System.Data.SqlClient;

namespace Emp.DAL
{
    public class EmployeeOperations
    {
        public static List<Employee> DisplayEmployees()
        {
            List<Employee> empList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "Keerthikadevi.DisplayEmployee_150772";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    empList = new List<Employee>();
                    while(dr.Read())
                    {
                        Employee emp = new Employee();
                        emp.EmpId = Convert.ToInt32(dr["EmpId"]);
                        emp.EmpName = dr["EmpName"].ToString();
                        emp.DeptCode = Convert.ToInt32(dr["DeptCode"]);
                        emp.DOB = Convert.ToDateTime(dr["DOB"]);
                        emp.Address = dr["Address"].ToString();

                        empList.Add(emp);
                    }
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empList;
        }

        public static int UpdateEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[Keerthikadevi].[usp_UpdateEmployee_150772]";

                cmd.Parameters.AddWithValue("@eId", emp.EmpId);
                cmd.Parameters.AddWithValue("@dcode", emp.DeptCode);
                cmd.Parameters.AddWithValue("@address", emp.Address);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteEmployee(int empId)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[Keerthikadevi].[usp_DeleteEmployee_150772]";

                cmd.Parameters.AddWithValue("@eId", empId);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Employee SearchEmployeee(int EmpId)
        {
            Employee emp = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[Keerthikadevi].[usp_SearchEmployee_150772]";

                cmd.Parameters.AddWithValue("@eId", EmpId);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    dr.Read();
                    emp = new Employee();
                    emp.EmpId = Convert.ToInt32(dr["EmpId"]);
                    emp.EmpName = dr["EmpName"].ToString();
                    emp.DeptCode = Convert.ToInt32(dr["DeptCode"]);
                    emp.DOB = Convert.ToDateTime(dr["DOB"]);
                    emp.Address = dr["Address"].ToString();
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;

        }

        public static int InsertEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[Keerthikadevi].[usp_InsertEmployee_150772]";

                cmd.Parameters.AddWithValue("@eId", emp.EmpId);
                cmd.Parameters.AddWithValue("@ename", emp.EmpName);
                cmd.Parameters.AddWithValue("@dcode", emp.DeptCode);
                cmd.Parameters.AddWithValue("@dob", emp.DOB);
                cmd.Parameters.AddWithValue("@address", emp.Address);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
