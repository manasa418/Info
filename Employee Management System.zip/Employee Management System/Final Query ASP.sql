﻿use [16MayCHN]
create table Keerthikadevi.Emp_LoginUser1_150772
(
UserName varchar(20),                             
Password varchar(20)
);

insert into Keerthikadevi.Emp_LoginUser1_150772(UserName,Password)
values('admin','admin@123'),
('pravin','pravin@123')


CREATE PROC Keerthikadevi.[usp_ValidateLogin2_150772]
(
@username VARCHAR(20),
@password VARCHAR(20)
)
AS                                            
BEGIN
SELECT UserName
FROM Emp1_LoginUser_150772
WHERE UserName = @username AND Password = @password
END

create table Keerthikadevi.Employee_ASP_150772
(
EmpId int,
EmpName varchar(20),
DeptCode int,
DOB DateTime,
Address varchar(30)
);


CREATE PROC Keerthikadevi.usp_InsertEmployee_150772
(
@eId INT,
@ename VARCHAR(50),
@dcode INT,
@dob DATE,
@address VARCHAR(50)
)
AS
BEGIN
INSERT INTO Employee_ASP_150772 (EmpId, EmpName, DeptCode, DOB, Address)
VALUES (@eId, @ename, @dcode, @dob, @address)
END

CREATE PROC Keerthikadevi.DisplayEmployee_150772
AS
BEGIN
SELECT * FROM Keerthikadevi.Employee_ASP_150772
END

SELECT * FROM Keerthikadevi.Employee_ASP_150772

EXEC Keerthikadevi.usp_InsertEmployee_150772 1,'Keerthi',23,'10-21-2018','Hyderabad'

CREATE PROC Keerthikadevi.usp_SearchEmployee_150772
(
@eId  INT
)
AS
BEGIN
SELECT * FROM Employee_ASP_150772 WHERE EmpId = @eId
END


CREATE PROC Keerthikadevi.usp_UpdateEmployee_150772
(
@eId  INT,
@dcode  INT,
@address  VARCHAR(50)
)
AS
BEGIN
UPDATE Employee_ASP_150772
SET DeptCode = @dcode,
Address = @address
WHERE EmpId = @eId
END


CREATE PROC Keerthikadevi.usp_DeleteEmployee_150772
(
@eId  INT
)
AS
BEGIN
DELETE FROM Employee_ASP_150772 WHERE EmpId = @eId
END

