﻿using Emp.BL;
using Emp.Entity;
using Emp.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Emp.PL
{
    public partial class SearchEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            Master.Logout = true;
            Master.Menu = true;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                emp.EmpId = Convert.ToInt32(txtEmpId.Text);
                emp.EmpName = txtEmpName.Text;
                emp.DeptCode = Convert.ToInt32(txtDeptCode.Text);
                emp.DOB = Convert.ToDateTime(txtDOB.Text);
                emp.Address = txtAddress.Text;

                int recordsAffected = EmployeeValidation.UpdateEmployee(emp);


                if (recordsAffected > 0)
                {
                    Response.Write("<script type='text/javascript'> alert('Employee Record Updated Successfully'); </script>");
                }
                else
                {
                    throw new EmployeeException("Employee record cannnot be updated");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                int id = Convert.ToInt32(txtEmpId.Text);

                int rowsAffected = EmployeeValidation.DeleteStudent(id);

                if(rowsAffected>0)
                {
                    Response.Write("<script type='text/javascript'>alert('Employee Record Deleted Successfully');</script>");
                }
                else
                {
                    throw new EmployeeException("Employee record cannnot be Deleted!!");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();

                int id = Convert.ToInt32(txtEmpId.Text);
                emp = EmployeeValidation.SearchEmployee(id);

                txtEmpName.Text = emp.EmpName;
                txtDeptCode.Text = emp.DeptCode.ToString();
                txtDOB.Text=emp.DOB.ToString("yyyy-MM-dd");
                txtAddress.Text = emp.Address;
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }

            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }
    }
}