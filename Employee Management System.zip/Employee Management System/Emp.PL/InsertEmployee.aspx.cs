﻿using Emp.BL;
using Emp.Entity;
using Emp.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Emp.PL
{
    public partial class InsertEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            Master.Logout = true;
            Master.Menu = true;
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                emp.EmpId = Convert.ToInt32(txtEmpId.Text);
                emp.EmpName = txtEmpName.Text;
                emp.DeptCode = Convert.ToInt32(txtDeptCode.Text);
                emp.DOB = Convert.ToDateTime(txtDOB.Text);
                emp.Address = txtAddress.Text;

                int recordsAffected = EmployeeValidation.InsertEmployee(emp);

                if(recordsAffected>0)
                {
                    Response.Write("<script type='text/javascript'>alert('Employee Record Inserted Successfully');</script>");
                }
                else
                {
                    throw new EmployeeException("Employee record not inserted");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script type='text/javascript'>alert('" + ex.Message + "');</script>");
            }
        }
    }
}