﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Emp.Entity;
using Emp.Exception;
using Emp.DAL;

namespace Emp.BL
{
    public class EmployeeValidation
    {
        public static List<Employee> DisplayEmployees()
        {
            List<Employee> empList = null;

            try
            {
                empList = EmployeeOperations.DisplayEmployees();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empList;
        }

        public static int InsertEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = EmployeeOperations.InsertEmployee(emp);
            }
            catch(EmployeeException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = EmployeeOperations.UpdateEmployee(emp);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Employee SearchEmployee(int EmpId)
        {
            Employee emp = null;

            try
            {
                emp = EmployeeOperations.SearchEmployeee(EmpId);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }

        public static int DeleteStudent(int EmpId)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = EmployeeOperations.DeleteEmployee(EmpId);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
    }

